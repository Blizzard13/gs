<?php

namespace GameapModules\Ftp\Exceptions;

use Gameap\Exceptions\GameapException;

class FtpModuleException extends GameapException
{

}